package com.example.hp.fruitsorder;

class Fruits {
    String[] images={"https://freepngimg.com/thumb/banana/33867-8-banana.png",
            "http://www.pngall.com/wp-content/uploads/2016/04/Apple-Fruit-High-Quality-PNG.png",
            "http://www.pngall.com/wp-content/uploads/2016/04/Mango-Free-PNG-Image.png",
            "http://realfruitpowernepal.com/assets/images/products/thumbs/1495961513_pineapple_thumb.png",
            "https://purepng.com/public/uploads/large/purepng.com-lycheefruitslycheelitchiliecheelizhili-zhilichee-981525183308x0ogy.png",
            "http://www.pngall.com/wp-content/uploads/2016/04/Pomegranate-Free-PNG-Image.png",
            "http://realfruitpowernepal.com/assets/images/products/thumbs/1466428238_Orange_Image_thumb.png",
            "http://www.pngpix.com/download/2720",
            "http://pngimg.com/uploads/pear/pear_PNG3467.png",
            "http://www.pngmart.com/files/3/Papaya-PNG-File.png",
            "http://realfruitpowernepal.com/assets/images/products/thumbs/1466428314_peach_Image_thumb.png",
            "https://static1.squarespace.com/static/5320c154e4b011a3c71a0cb8/5c140fbb21c67c015d20ca8b/5c1413584ae23788e7fe5697/1544819589564/Strawberries.png?format=300w",
            "https://purepng.com/public/uploads/large/purepng.com-grapesgrapesfruitbluesweet-481521375967iqqtb.png",
            "http://pngimg.com/uploads/grape/grape_PNG2996.png",
            "https://www.freepngimg.com/thumb/watermelon/2-2-watermelon-free-download-png.png",
            "https://i.dlpng.com/static/png/481147_preview.png",
            "https://www.freepngimg.com/thumb/kiwi/5-2-kiwi-transparent.png",
             "https://www.pngarts.com/files/4/Avocado-PNG-Transparent-Image.png",
            "https://www.stickpng.com/assets/images/5a5f62adee40df432bfac55a.png"
    };
    String[] names={"Banana", "Apple", "Mango", "Pineapple", "Litchi","Pomegranate","Orange","Mousambi","Pear",
            "Papaya","Peach","Strawberry","Black Grapes","Green Grapes","WaterMelon","MuskMelon","Kiwi","Avocado","Gauava"

    };
    String [] price={"Rs.60","Rs.100","Rs.50","Rs.100","Rs.80","Rs.500","Rs.80","Rs.50","Rs.100","Rs.60","Rs.80","Rs.300",
            "Rs.100","Rs.100","Rs.20","Rs.20","Rs.800","Rs.200","Rs.50"
    };
    String[] description={"Enjoy the joyness of peeling","Juicy and Fruity","Its Mango season!","Fresh and Juicy","Its Red!","Enjoy its Juiceness",
            "Appears to green but white whithin","Best for gut problems","its Peachy season","Its sweet!","purple not black","White appears to be green",
            "Eat Mitha pani","Refreshing Melon","It's Beautiful inside","Its Videshi!","Its Evergreen","Its Videshi!","Its Evergreen"};


}
