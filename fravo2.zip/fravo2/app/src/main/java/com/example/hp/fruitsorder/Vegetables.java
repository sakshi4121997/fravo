package com.example.hp.fruitsorder;

class Vegetables {
    String[] images={
            "http://pngimg.com/uploads/garlic/garlic_PNG12802.png",
            "https://www.stickpng.com/assets/images/5b4eed0cc051e602a568ce0c.png",
            "http://www.pngpix.com/wp-content/uploads/2016/03/Fresh-Chili-PNG-image.png",
            "https://www.freepngimg.com/thumb/tomato/6-tomato-png-image-thumb.png",
            "http://pluspng.com/img-png/onion-png-onion-png-image-788.png",
            "http://www.pngall.com/wp-content/uploads/2016/04/Potato-PNG-Picture.png",
            "https://www.freepngimg.com/thumb/ladyfinger/42356-1-lady-finger-free-download-png-hd-thumb.png",
             "https://ya-webdesign.com/transparent450_/green-pumpkin-png-2.png",
            "http://www.pngmart.com/files/7/Mooli-PNG-Transparent-Image.png",
            "https://www.pngarts.com/files/4/Carrot-PNG-Download-Image.png",
            "https://purepng.com/public/uploads/large/purepng.com-bitter-gourdvegetables-bitter-melon-bitter-gourd-momordica-charantia-bitter-squash-balsam-pear-941524726197qszna.png",
            "http://vicamart.com/wp-content/uploads/2017/10/ridge-gourd_burned.png",
            "https://vegify.in/wp-content/uploads/2019/02/1549113837291.png",
            "https://www.hapurhub.com/wp-content/uploads/2019/01/local-vegetable-capsicum-green-hybrid-v-250-g-3.png",
            "https://cdn.pixabay.com/photo/2017/07/09/05/36/vegetable-2486289_1280.png",
            "https://www.redsunfarms.com/img/product/pack1/YellowPepperbulk.png?v=1.0",
            "https://stickeroid.com/uploads/pic/full-pngmart/37c73939bbda1f6fb2692b78e89e710d9009383c.png",
            "http://pngimg.com/uploads/cauliflower/cauliflower_PNG12686.png",
            "https://www.pngarts.com/files/1/Cabbage-PNG-Background-Image.png",
            "https://purepng.com/public/uploads/large/purepng.com-brinjalvegetables-brinjal-eggplant-melongene-garden-egg-guinea-squash-941524725891tf1xf.png",
            "http://pngimg.com/uploads/beet/beet_PNG52.png"

    };
    String[] names={"Garlic","Ginger","Green Chillis","Tomato","Onion","Potato","Ladyfinger","Pumpkink",
            "Raddish","Carrot","BitterGourd","RidgeGourd","BottleGourd","Capsicum","Red Bell Pepper","Yellow Bell Pepper","Cucumber","Caulflower","Cabbage",
            "EggPlant", "BeetRoot"
    };
    String[] price={"Rs.150","Rs.58","Rs.59","Rs.65","Rs.40","Rs.20","Rs.50","Rs.25","Rs.30","Rs.44","Rs.45","Rs.35","Rs.30","Rs.55","Rs.190","Rs.190",
            "Rs.30","Rs.32","Rs.12","Rs.30","Rs.30"};
    String[] description={"Enhance the taste of your sabji","Main Ingredient for tea","Its Spicy","Add some Tango","Will make you Cry","Its Your  favourite Aloo",
            "Its not any lady but a sabji","Enjoy By making sweet petha","Seems to Red it's Mooli","Be a rabbit","Its Bitter but Healthy for you ",
            "Tori","Lauki","So called Shimlka Mirch","","","","","","",""


    };
}
